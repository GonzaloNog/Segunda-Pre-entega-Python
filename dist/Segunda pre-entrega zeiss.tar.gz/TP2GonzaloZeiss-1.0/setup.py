from setuptools import setup

setup(
    name="TP2GonzaloZeiss",
    version="1.0",
    description="Segunda pre entrega",
    author="Zeiss Gonzalo",
    packages=["", "SegundoTrabajo", "PrimerTrabajo"]
)